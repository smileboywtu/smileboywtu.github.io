# set up the data base
DATABASE_URL = /db/recommend.db

