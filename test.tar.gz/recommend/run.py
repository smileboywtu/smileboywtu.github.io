"""

	this is the main run model.
	use the blueprint

"""

from flask import Flask
from music.music import music_recommend


# define the main app
app = Flask(__name__)
# load the config in config.py
app.config.from_object('config')


# register
app.register_blueprint(music_recommend, url_prefix='/recommendation')

# user define for test
if __name__ == '__main__':
    app.run()
