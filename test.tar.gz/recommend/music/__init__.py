from flask import Flask

app = Flask(__name__)

import music


# export
__all__ = ["app"]

