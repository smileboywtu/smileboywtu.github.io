"""
	
	view for the music recommendation.	
	here use the flask blueprint

"""

import sqlite3
from flask import g
from flask import Blueprint
from flask import render_template
from utils.cors import crossdomain


# create the blueprint
music_recommend = Blueprint('music_recommend', __name__, 
														template_folder='templates',
													  static_folder='static')


# connect to the db
def connect_db():
		connection = sqlite3.connect(app.config['DATABASE_URL'])
		connection.row_factory = sqlite3.Row
		return connection


def query_db(query, args=(), first=False):
    cursor = g.db.execute(query, args)
    returns = cursor.fetchall()
    cursor.close()
    return (returns[0] if returns else None) if first else returns


@music_recommend.before_request
def before_request():
		g.db = connect_db()


@music_recommend.teardown_request
def teardown_request(exception):
		db = getattr(g, 'db', None)
		if db is not None:
				db.close()


# define the view
@music_recommend.route("/music")
@crossdomain(origin='*')
def recommendation():
		musics = query_db("select name, singer from music_recommend")		
  	return render_template("musics.html", musics=musics)
